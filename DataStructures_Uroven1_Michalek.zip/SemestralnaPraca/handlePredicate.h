#include "libds/amt/implicit_sequence.h"
#include <functional>
template<typename J>
class HandlePredicate
{
public:
	HandlePredicate();
	~HandlePredicate();

	void setStartStr(string startStr) { this->startStr = startStr; };
	void setSubStr(string subStr) { this->subStr = subStr; };
	
	bool startsWithStr(string str) { return str.rfind(startStr, 0) == 0; }
	bool containsStr(string str) { return str.find(subStr) != std::string::npos; }

private:
	std::string startStr;
	std::string subStr;
};

template<typename J>
HandlePredicate<J>::HandlePredicate()
{
}

template<typename J>
HandlePredicate<J>::~HandlePredicate()
{
}
