#pragma once
#include "libds/amt/implicit_sequence.h"
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>

template<typename J>
class HandleInplut
{
public:
	HandleInplut();
	~HandleInplut();
	void loadFromFileObce();
	void loadFromFileOkresy();
	void loadFromFileKraje();
	void printObce();
	void printOkresy();
	void printKraje();
	ds::amt::ImplicitSequence<J>* getObce() { return this->ISObce; }
	ds::amt::ImplicitSequence<J>* getOkresy() { return this->ISOkresy; }
	ds::amt::ImplicitSequence<J>* getKraje() { return this->ISKraje; }
	

private:
	ds::amt::ImplicitSequence<J>* ISObce = new ds::amt::ImplicitSequence<J>(); // inicializacia
	ds::amt::ImplicitSequence<J>* ISOkresy = new ds::amt::ImplicitSequence<J>();
	ds::amt::ImplicitSequence<J>* ISKraje = new ds::amt::ImplicitSequence<J>();
};

template<typename J>
HandleInplut<J>::HandleInplut()
{
	
}

template<typename J>
HandleInplut<J>::~HandleInplut()
{
	delete this->ISObce;
	delete this->ISOkresy;
	delete this->ISKraje;
}

template<typename J>
inline void HandleInplut<J>::loadFromFileObce()
{
	int sortNum = 0;
	std::string code = "";
	std::string officialTitle = "";
	std::string mediumTitle = "";
	std::string shortTitle = "";
	std::string note = "";

	int c = 0;

	std::ifstream input("C:\\Users\\Filip\\Desktop\\skola\\6. semester\\AUS\\AUS-VS2022\\DataStructures\\SemestralnaPraca\\obce.csv");
	std::string item;
	std::string line;
	std::getline(input, item);
	while (std::getline(input, line))
	{
		if (line.find("Zahrani�ie") == std::string::npos)
		{
			c = 0;
			std::istringstream in(line);
			while (std::getline(in, item, ';'))
			{
				switch (c)
				{
				case 0:
					sortNum = stoi(item);
					break;
				case 1:
					code = item;

					break;
				case 2:
					officialTitle = item;
					break;
				case 3:
					mediumTitle = item;
					break;
				case 4:
					shortTitle = item;
					break;
				case 5:
					note = item;
					c = 0;
					break;
				}
				c++;
			}
			//std::cout << std::to_string(sortNum) << " " << code << " " << officialTitle << " " << mediumTitle << " " << shortTitle << " " << note << " " << std::endl;
			this->ISObce->insertLast().data_ = J(sortNum, code, officialTitle, mediumTitle, shortTitle, note);
		}
	}
	/*for (auto var : *this->ISObce)
	{
		std::cout << var.toString() << std::endl;
	}*/
}

template<typename J>
inline void HandleInplut<J>::loadFromFileOkresy()
{
	int sortNum = 0;
	std::string code = "";
	std::string officialTitle = "";
	std::string mediumTitle = "";
	std::string shortTitle = "";
	std::string note = "";

	int c = 0;

	std::ifstream input("C:\\Users\\Filip\\Desktop\\skola\\6. semester\\AUS\\AUS-VS2022\\DataStructures\\SemestralnaPraca\\okresy.csv");
	std::string item;
	std::string line;
	std::getline(input, item);
	while (std::getline(input, line))
	{
		if (line.find("Zahrani�ie") == std::string::npos)
		{
			c = 0;
			std::istringstream in(line);
			while (std::getline(in, item, ';'))
			{
				switch (c)
				{
				case 0:
					sortNum = stoi(item);
					break;
				case 1:
					code = item;
					break;
				case 2:
					officialTitle = item;
					break;
				case 3:
					mediumTitle = item;
					break;
				case 4:
					shortTitle = item;
					break;
				case 5:
					note = item;
					c = 0;
					break;
				}
				c++;
			}
			//std::cout << std::to_string(sortNum) << " " << code << " " << officialTitle << " " << mediumTitle << " " << shortTitle << " " << note << " " << std::endl;
			this->ISOkresy->insertLast().data_ = J(sortNum, code, officialTitle, mediumTitle, shortTitle, note);
		}
	}
	/*for (auto var : *this->ISObce)
	{
		std::cout << var.toString() << std::endl;
	}*/
}

template<typename J>
inline void HandleInplut<J>::loadFromFileKraje()
{
	int sortNum = 0;
	std::string code = "";
	std::string officialTitle = "";
	std::string mediumTitle = "";
	std::string shortTitle = "";
	std::string note = "";

	int c = 0;

	std::ifstream input("C:\\Users\\Filip\\Desktop\\skola\\6. semester\\AUS\\AUS-VS2022\\DataStructures\\SemestralnaPraca\\kraje.csv");
	std::string item;
	std::string line;
	std::getline(input, item);
	while (std::getline(input, line))
	{
		if (line.find("Zahrani�ie") == std::string::npos)
		{
			c = 0;
			std::istringstream in(line);
			while (std::getline(in, item, ';'))
			{
				switch (c)
				{
				case 0:
					sortNum = stoi(item);
					break;
				case 1:
					code = item;
					break;
				case 2:
					officialTitle = item;
					break;
				case 3:
					mediumTitle = item;
					break;
				case 4:
					shortTitle = item;
					break;
				case 5:
					note = item.substr(5);
					c = 0;
					break;
				}
				c++;
			}
			//std::cout << std::to_string(sortNum) << " " << code << " " << officialTitle << " " << mediumTitle << " " << shortTitle << " " << note << " " << std::endl;
			this->ISKraje->insertLast().data_ = J(sortNum, code, officialTitle, mediumTitle, shortTitle, note);
		}
	}
	/*for (auto var : *this->ISObce)
	{
		std::cout << var.toString() << std::endl;
	}*/
}

template<typename J>
inline void HandleInplut<J>::printObce()
{
	for (auto a : *ISObce)
	{
		std::cout << a.getShortTitle() << std::endl;
	}
}

template<typename J>
inline void HandleInplut<J>::printOkresy()
{
	for (auto a : *ISOkresy)
	{
		std::cout << a.getShortTitle() << std::endl;
	}
}

template<typename J>
inline void HandleInplut<J>::printKraje()
{
	for (auto a : *ISKraje)
	{
		std::cout << a.getShortTitle() << std::endl;
	}
}
