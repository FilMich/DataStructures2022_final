#include <codecvt>
#include "libds/heap_monitor.h"
#include <iostream>
#include "handleInput.h"

#include "libds/amt/implicit_sequence.h"

#include <Windows.h>

#include "uzemnaJednotka.h"

#include "handlePredicate.h"

#include "filter.h"



int main() {
	initHeapMonitor();
	SetConsoleOutputCP(1250);
	SetConsoleCP(1250);
	setlocale(LC_ALL, "slovak");
	HandleInplut<UzemnaJednotka>* input = new HandleInplut<UzemnaJednotka>();
	HandlePredicate<UzemnaJednotka>* predicate = new HandlePredicate<UzemnaJednotka>();
	Filter<UzemnaJednotka>* filter = new Filter<UzemnaJednotka>();
	input->loadFromFileObce();
	input->loadFromFileOkresy();
	input->loadFromFileKraje();

	bool loop = true;
	int i = 0; //input from console
	int ii = 0; //input from console
	string subStr = "";
	string startStr = "";

	while (loop)
	{
		system("cls"); //clear console 

		cout << "Menu : " << endl;

		cout << "1. Filter Obce" << endl;
		cout << "2. Filter Okresy" << endl;
		cout << "3. Filter Kraje" << endl;
		cout << "4. Exit" << endl;

		cout << "Enter number to choose from options : ";
		cin >> i;

		switch (i)
		{
		case 1:
			cout << "Filter Obce menu : " << endl;

			cout << "1. contains string" << endl;
			cout << "2. starts with string" << endl;
			cout << "3. print without filter" << endl;

			cout << "Enter number to choose from options : ";
			cin >> ii;

			switch (ii)
			{
			case 1:
				cout << "Enter string : " << endl;
				cin >> subStr;

				transform(subStr.begin(), subStr.end(), subStr.begin(), ::tolower);

				//cout << "11" << endl;
				predicate->setSubStr(subStr);
				filter->filterData(input->getObce()->begin(), input->getObce()->end(),
					[&](UzemnaJednotka& uj) { string s = ""; s.assign(uj.getShortTitle()); transform(s.begin(), s.end(), s.begin(), ::tolower); ; return predicate->containsStr(s); });
				system("pause");
				break;
			case 2:
				cout << "Enter string : " << endl;
				cin >> startStr;

				if (!isupper(startStr[0])) {
					startStr[0] = toupper(startStr[0]);
				}
				//cout << "12" << endl;
				predicate->setStartStr(startStr);
				filter->filterData(input->getObce()->begin(), input->getObce()->end(),
					[&](UzemnaJednotka& uj) { return predicate->startsWithStr(uj.getShortTitle()); });
				system("pause");
				break;
			case 3:
				input->printObce();
				system("pause");
				break;
			default:
				cout << "invalid input" << endl;
				system("pause");
				break;
			}

			break;
		case 2:
			cout << "Filter Okresy menu : " << endl;

			cout << "1. contains string" << endl;
			cout << "2. starts with string" << endl;
			cout << "3. print without filter" << endl;

			cout << "Enter number to choose from options : ";
			cin >> ii;

			switch (ii)
			{
			case 1:
				cout << "Enter string : " << endl;
				cin >> subStr;

				transform(subStr.begin(), subStr.end(), subStr.begin(), ::tolower);

				//cout << subStr + "21" << endl;
				predicate->setSubStr(subStr);
				filter->filterData(input->getOkresy()->begin(), input->getOkresy()->end(),
					[&](UzemnaJednotka& uj) {string s = ""; s.assign(uj.getShortTitle()); transform(s.begin(), s.end(), s.begin(), ::tolower); ; return predicate->containsStr(s); });
				system("pause");
				break;
			case 2:
				cout << "Enter string : " << endl;
				cin >> startStr;

				if (!isupper(startStr[0])) {
					startStr[0] = toupper(startStr[0]);
				}
				//cout << "22" << endl;
				predicate->setStartStr(startStr);
				filter->filterData(input->getOkresy()->begin(), input->getOkresy()->end(),
					[&](UzemnaJednotka& uj) { return predicate->startsWithStr(uj.getShortTitle()); });
				system("pause");
				break;
			case 3:
				input->printOkresy();
				system("pause");
				break;
			default:
				cout << "invalid input" << endl;
				system("pause");
				break;
			}

			break;
		case 3:
			cout << "Filter Kraje menu : " << endl;

			cout << "1. contains string" << endl;
			cout << "2. starts with string" << endl;
			cout << "3. print without filter" << endl;

			cout << "Enter number to choose from options : ";
			cin >> ii;

			switch (ii)
			{
			case 1:
				cout << "Enter string : " << endl;
				cin >> subStr;

				transform(subStr.begin(), subStr.end(), subStr.begin(), ::tolower);

				//cout << "31" << endl;
				predicate->setSubStr(subStr);
				filter->filterData(input->getObce()->begin(), input->getObce()->end(),
					[&](UzemnaJednotka& uj) { string s = ""; s.assign(uj.getShortTitle()); transform(s.begin(), s.end(), s.begin(), ::tolower); ; return predicate->containsStr(s); });
				system("pause");
				break;
			case 2:
				cout << "Enter string : " << endl;
				cin >> startStr;

				if (!isupper(startStr[0])) {
					startStr[0] = toupper(startStr[0]);
				}

				//cout << "32" << endl;

				predicate->setStartStr(startStr);
				filter->filterData(input->getKraje()->begin(), input->getKraje()->end(),
					[&](UzemnaJednotka& uj) { return predicate->startsWithStr(uj.getShortTitle()); });
				system("pause");
				break;
			case 3:
				input->printKraje();
				system("pause");
				break;
			default:
				cout << "invalid input" << endl;
				system("pause");
				break;
			}

			break;
		case 4:
			loop = false;
			break;
		default:
			cout << "invalid input" << endl;
			system("pause");
			break;
		}
	}
	delete predicate;
	delete input;
	delete filter;
}