#include "libds/amt/implicit_sequence.h"

template<typename J>
class Filter
{
public:
	Filter();
	~Filter();

	void filterData(typename ds::amt::ImplicitSequence<J>::ImplicitSequenceIterator begin, typename ds::amt::ImplicitSequence<J>::ImplicitSequenceIterator end, std::function<bool(UzemnaJednotka&)> predicate);


private:

};

template<typename J>
Filter<J>::Filter()
{
}

template<typename J>
Filter<J>::~Filter()
{
}

template<typename J>
inline void Filter<J>::filterData(typename ds::amt::ImplicitSequence<J>::ImplicitSequenceIterator begin, typename ds::amt::ImplicitSequence<J>::ImplicitSequenceIterator end, std::function<bool(UzemnaJednotka&)> predicate)
{
	ds::amt::ImplicitSequence<J> pom;
	for (auto it = begin; it != end; ++it)
	{
		if (predicate(*it))
		{
			pom.insertLast().data_ = *it;
		}
	}

	for (auto a : pom) {
		std::cout << a.getShortTitle() << std::endl;   //opytat sa na vracanie IS 
	}
}