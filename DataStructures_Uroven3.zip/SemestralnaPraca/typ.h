#pragma once
enum class Typ {
	STAT,
	KRAJ,
	OKRES,
	OBEC
};