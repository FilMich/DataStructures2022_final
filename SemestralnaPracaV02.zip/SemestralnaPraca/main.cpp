#include <codecvt>
#include "libds/heap_monitor.h"
#include <iostream>
#include "handleInput.h"

#include "libds/amt/implicit_sequence.h"

#include <Windows.h>

#include "uzemnaJednotka.h"



int main() {
	initHeapMonitor();
	SetConsoleOutputCP(1250);
	SetConsoleCP(1250);
	setlocale(LC_ALL, "slovak");
	//ds::amt::ImplicitSequence<int>* IS = new ds::amt::ImplicitSequence<int>();
	//IS->insertFirst();
	HandleInplut<UzemnaJednotka>* hI = new HandleInplut<UzemnaJednotka>();
	hI->loadFromFileObce();
	hI->loadFromFileOkresy();
	hI->loadFromFileKraje();
	for (auto var : *hI->ISObce) 
	{
		std::cout << var.toString() << std::endl;
	}
	for (auto var : *hI->ISOkresy)
	{
		std::cout << var.toString() << std::endl;
	}
	for (auto var : *hI->ISKraje)
	{
		std::cout << var.toString() << std::endl;
	}
	delete hI;
	//delete IS;
}